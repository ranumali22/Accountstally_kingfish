const express = require("express");
const router = express.Router();

const journalController = require("../controllers/jurnal.controller");
// const authMiddleware = require("../middleware/companyAuth");
const { companyAuth } = require("../middleware/companyAuth");

// =======================================================
// 🔹 JOURNAL ROUTES
// =======================================================

// ➕ Create Journal
router.post("/create", companyAuth, journalController.createJournal);

// ✏️ Update Journal
router.put("/update/:id", companyAuth, journalController.updateJournal);

// ❌ Delete Journal (Soft Delete)
router.delete("/delete/:id", companyAuth, journalController.deleteJournal);

// 👁️ Get Journal by ID (Edit View)
router.get("/:id", companyAuth, journalController.getJournalById);

router.get("/company/:company_id", companyAuth, journalController.getJournalsByCompany);

module.exports = router;
