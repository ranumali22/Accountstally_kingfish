const db = require("../config/db");

async function getPurchaseReturnLedgerId(conn, company_id) {
  // 1. Check if ledger exists
  const [rows] = await conn.execute(
    `
    SELECT p.id
    FROM party p
    WHERE (p.company_name LIKE '%Purchase%' OR p.company_name LIKE '%Return%')
    AND p.company_id = ?
    LIMIT 1
    `,
    [company_id],
  );

  if (rows.length) return rows[0].id;

  // 2. Check if group exists, if not create it
  let [groups] = await conn.execute(
    `SELECT id FROM groups_master WHERE name='Purchase Return' AND company_id=?`,
    [company_id]
  );

  let groupId;
  if (!groups.length) {
    // Create Group under 'Direct Expenses' or similar if needed, 
    // but here we'll just create it as a primary group for now to unblock.
    const [res] = await conn.execute(
      `INSERT INTO groups_master (name, company_id, parent_id) VALUES (?, ?, 0)`,
      ['Purchase Return', company_id]
    );
    groupId = res.insertId;
  } else {
    groupId = groups[0].id;
  }

  // 3. Create the Ledger (System entry)
  const [ledgerRes] = await conn.execute(
    `INSERT INTO party (company_name, group_id, company_id, user_type) VALUES (?, ?, ?, ?)`,
    ['Purchase Return', groupId, company_id, 'system']
  );

  return ledgerRes.insertId;
}

const generateVoucherNumber = require("../utils/generateVoucherNumber");

exports.createDebitNote = async (req, res) => {
  const conn = await db.getConnection();

  try {
    const {
      company_id,
      purchase_invoice_no,
      voucher_date,
      party_id,
      narration,
      total_amount,
      rows,
    } = req.body;

    if (!company_id || !party_id || !voucher_date || !rows?.length) {
      return res.status(400).json({
        success: false,
        message: "Missing required fields",
      });
    }

    await conn.beginTransaction();

    const total = Number(total_amount || 0);

    if (total <= 0) throw new Error("Invalid amount");

    const debit_note_no = await generateVoucherNumber(conn, company_id, "DN");

    // get purchase return ledger

    const PURCHASE_RETURN_LEDGER = await getPurchaseReturnLedgerId(
      conn,
      company_id,
    );

    // get state for GST

    const [[company]] = await conn.query(
      `SELECT state FROM companies WHERE id=?`,
      [company_id],
    );

    const [[party]] = await conn.query(`SELECT state FROM party WHERE id=?`, [
      party_id,
    ]);

    const isIntra =
      company.state?.toLowerCase().trim() === party.state?.toLowerCase().trim();


      // ✅ GET LEDGER NUMBER
const [[ledger]] = await db.query(
  `
  SELECT ledger_number 
  FROM ledgers 
  WHERE party_id = ? 
  AND company_id = ?
  LIMIT 1
  `,
  [Number(party_id), Number(company_id)]
);

const ledger_number = ledger?.ledger_number || null;

    // INSERT HEADER

    await conn.execute(
      `
  INSERT INTO debit_note
(
  debit_note_no,
  company_id,
  purchase_invoice_no,
  voucher_date,
  mode,
  party_id,
  ledger_number,
  narration,
  total_amount,
  status
)
      VALUES(?,?,?,?,?,?,?,?,?,'active')
    `,
      [
        debit_note_no,
        company_id,
        purchase_invoice_no,
        voucher_date,
        req.body.mode || "ITEM",
        party_id,
        ledger_number,
        narration || null,
        total,
      ],
    );

    // INSERT ITEMS

    for (const r of rows) {
      const taxAmount = Number(r.tax_amount || 0);

      let cgst = 0,
        sgst = 0,
        igst = 0;

      if (isIntra) {
        cgst = taxAmount / 2;
        sgst = taxAmount / 2;
      } else {
        igst = taxAmount;
      }

      await conn.execute(
        `
        INSERT INTO debit_note_items
        (
          debit_note_no,
          item_name,
          hsn,
          qty,
          unit_id,
          price_per_unit,
          tax_id,
          tax_percent,
          cgst_amount,
          sgst_amount,
          igst_amount,
          tax_amount,
          status
        )
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,'active')
      `,
        [
          debit_note_no,
          r.item_name || "Service",
          r.hsn || null,
          r.qty || 1,
          r.unit_id || null,
          r.price_per_unit || 0,
          r.tax_id || null,
          r.tax_percent || 0,
          cgst,
          sgst,
          igst,
          taxAmount,
        ],
      );
    }

    // =============================
    // LEDGER ENTRY (SAME AS CREDIT NOTE PATTERN)
    // =============================

    // PARTY DR

    await conn.execute(
      `
      INSERT INTO ledger_entries
      (
        company_id,
        entry_date,
        source_type,
        source_id,
        ledger_id,
        party_id,
        debit,
        credit,
        narration,
        status
      )
      VALUES(?,?,?,?,?,?,?,?,?,?)
    `,
      [
        company_id,
        voucher_date,
        "DEBIT_NOTE",
        debit_note_no,
        party_id,
        party_id,
        total,
        0,
        narration || "Purchase Return",
        "active",
      ],
    );

    // PURCHASE RETURN CR

    await conn.execute(
      `
      INSERT INTO ledger_entries
      (
        company_id,
        entry_date,
        source_type,
        source_id,
        ledger_id,
        debit,
        credit,
        narration,
        status
      )
      VALUES(?,?,?,?,?,?,?,?,?)
    `,
      [
        company_id,
        voucher_date,
        "DEBIT_NOTE",
        debit_note_no,
        PURCHASE_RETURN_LEDGER,
        0,
        total,
        narration || "Purchase Return",
        "active",
      ],
    );

    // UPDATE PURCHASE BILL DUE

    await conn.execute(
      `
      UPDATE purchase_bill
      SET due_amount =
      GREATEST(due_amount - ?,0)
      WHERE supplier_invoice_no=?
      AND company_id=?
    `,
      [total, purchase_invoice_no, company_id],
    );

    await conn.commit();

    res.json({
      success: true,
      debit_note_no,
    });
  } catch (err) {
    await conn.rollback();

    console.error(err);

    res.status(500).json({
      success: false,
      error: err.message,
    });
  } finally {
    conn.release();
  }
};

exports.listDebitNotes = async (req, res) => {
  try {
    const { company_id, fromDate, toDate, party_id, search } = req.query;

    if (!company_id) {
      return res.status(400).json({
        success: false,
        message: "company_id required",
      });
    }

    let where = `WHERE dn.status='active' AND dn.company_id=?`;

    const params = [company_id];

    if (fromDate) {
      where += ` AND dn.voucher_date>=?`;
      params.push(fromDate);
    }

    if (toDate) {
      where += ` AND dn.voucher_date<=?`;
      params.push(toDate);
    }

    if (party_id) {
      where += ` AND dn.party_id=?`;
      params.push(party_id);
    }

    if (search) {
      where += `
      AND (
        dn.debit_note_no LIKE ?
        OR dn.purchase_invoice_no LIKE ?
        OR p.company_name LIKE ?
      )
      `;

      const like = `%${search}%`;

      params.push(like, like, like);
    }

    const [notes] = await db.query(
      `
      SELECT

        dn.id,
        dn.debit_note_no,
        dn.company_id,
        dn.purchase_invoice_no,

        DATE_FORMAT(dn.voucher_date,'%Y-%m-%d') AS voucher_date,

        dn.party_id,
        dn.total_amount,
        dn.narration,
        dn.created_at,

        p.company_name AS party_name,
        p.gst_number,
        p.mobile_number

      FROM debit_note dn

      LEFT JOIN party p
        ON p.id = dn.party_id

      ${where}

      ORDER BY dn.id DESC
      `,
      params,
    );

    res.json({
      success: true,
      count: notes.length,
      data: notes,
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message,
    });
  }
};

exports.getDebitNoteById = async (req, res) => {
  try {
    const { debit_note_no } = req.params;
    const { company_id } = req.query;

    if (!company_id) {
      return res.status(400).json({
        success: false,
        message: "company_id required",
      });
    }

    const [[header]] = await db.query(
      `
      SELECT

        dn.*,

        p.company_name AS party_name,
        p.gst_number,
        p.mobile_number,
        p.address,
        p.state,
        p.city,
        p.pincode

      FROM debit_note dn

      LEFT JOIN party p
        ON p.id = dn.party_id

      WHERE dn.debit_note_no=?
      AND dn.company_id=?
      AND dn.status='active'
      `,
      [debit_note_no, company_id],
    );

    if (!header) {
      return res.status(404).json({
        success: false,
        message: "Debit note not found",
      });
    }

    const [items] = await db.query(
      `
      SELECT

        dni.*,

        um.display_name AS unit_name,

        tm.tax_name,
        tm.tax_percent AS master_tax_percent,

        (dni.price_per_unit * dni.qty) + dni.tax_amount
        AS total_amount

      FROM debit_note_items dni

      LEFT JOIN unit_master um
        ON um.id = dni.unit_id

      LEFT JOIN tax_master tm
        ON tm.id = dni.tax_id

      WHERE dni.debit_note_no=?
      AND dni.status='active'
      `,
      [debit_note_no],
    );

    res.json({
      success: true,
      header,
      items,
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message,
    });
  }
};

exports.deleteDebitNote = async (req, res) => {
  const conn = await db.getConnection();

  try {
    const { debit_note_no } = req.params;
    const { company_id } = req.body;

    await conn.beginTransaction();

    const [[dn]] = await conn.query(
      `
      SELECT purchase_invoice_no,total_amount
      FROM debit_note
      WHERE debit_note_no=?
      AND company_id=?
      AND status='active'
      `,
      [debit_note_no, company_id],
    );

    if (!dn) {
      throw new Error("Debit note not found");
    }

    await conn.execute(
      `
      UPDATE debit_note
      SET status='deleted',deleted_at=NOW()
      WHERE debit_note_no=?
      AND company_id=?
      `,
      [debit_note_no, company_id],
    );

    await conn.execute(
      `
      UPDATE debit_note_items
      SET status='deleted'
      WHERE debit_note_no=?
      `,
      [debit_note_no],
    );

    await conn.execute(
      `
      UPDATE ledger_entries
      SET status='deleted',deleted_at=NOW()
      WHERE source_type='DEBIT_NOTE'
      AND source_id=?
      AND company_id=?
      `,
      [debit_note_no, company_id],
    );

    await conn.execute(
      `
      UPDATE purchase_bill
      SET due_amount =
      GREATEST(due_amount - ?, 0)
      WHERE supplier_invoice_no =?
      AND company_id=?
      `,
      [dn.total_amount, dn.purchase_invoice_no, company_id],
    );

    await conn.commit();

    res.json({
      success: true,
      message: "Debit note deleted successfully",
    });
  } catch (err) {
    await conn.rollback();

    res.status(500).json({
      success: false,
      error: err.message,
    });
  } finally {
    conn.release();
  }
};

exports.updateDebitNote = async (req, res) => {
  const conn = await db.getConnection();

  try {
    const { debit_note_no } = req.params;

    const {
      company_id,
      purchase_invoice_no,
      voucher_date,
      mode,
      party_id,
      narration,
      total_amount,
      rows,
    } = req.body;

    if (!company_id || !party_id || !voucher_date || !rows?.length) {
      return res.status(400).json({
        success: false,
        message: "Missing required fields",
      });
    }

    await conn.beginTransaction();

    // 1️⃣ GET OLD DEBIT NOTE

    const [[oldDN]] = await conn.query(
      `
      SELECT total_amount, purchase_invoice_no
      FROM debit_note
      WHERE debit_note_no=?
      AND company_id=?
      AND status='active'
    `,
      [debit_note_no, company_id],
    );

    if (!oldDN) throw new Error("Debit Note not found");

    // 2️⃣ RESTORE OLD PURCHASE DUE

    await conn.execute(
      `
      UPDATE purchase_bill
      SET due_amount = due_amount + ?
      WHERE supplier_invoice_no=?
      AND company_id=?
    `,
      [oldDN.total_amount, oldDN.purchase_invoice_no, company_id],
    );

    // 3️⃣ SOFT DELETE OLD DATA

    await conn.execute(
      `
      UPDATE debit_note
      SET status='deleted', deleted_at=NOW()
      WHERE debit_note_no=?
      AND company_id=?
    `,
      [debit_note_no, company_id],
    );

    await conn.execute(
      `
      UPDATE debit_note_items
      SET status='deleted'
      WHERE debit_note_no=?
    `,
      [debit_note_no],
    );

    await conn.execute(
      `
      UPDATE ledger_entries
      SET status='deleted', deleted_at=NOW()
      WHERE source_type='DEBIT_NOTE'
      AND source_id=?
      AND company_id=?
    `,
      [debit_note_no, company_id],
    );

    // 4️⃣ GET LEDGER

    const PURCHASE_RETURN_LEDGER = await getPurchaseReturnLedgerId(
      conn,
      company_id,
    );

    // 5️⃣ INSERT NEW HEADER

    const total = Number(total_amount || 0);

    await conn.execute(
      `
      INSERT INTO debit_note
      (
        debit_note_no,
        company_id,
        purchase_invoice_no,
        voucher_date,
        mode,
        party_id,
        narration,
        total_amount,
        status
      )
      VALUES(?,?,?,?,?,?,?,?,?,'active')
      `,
      [
        debit_note_no,
        company_id,
        purchase_invoice_no,
        voucher_date,
        req.body.mode || "ITEM",
        party_id,
        narration || null,
        total,
      ],
    );

    // 6️⃣ INSERT ITEMS

    for (const r of rows) {
      const taxAmount = Number(r.tax_amount || 0);

      await conn.execute(
        `
        INSERT INTO debit_note_items
        (
          debit_note_no,
          item_name,
          hsn,
          qty,
          unit_id,
          price_per_unit,
          tax_id,
          tax_percent,
          cgst_amount,
          sgst_amount,
          igst_amount,
          tax_amount,
          status
        )
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,'active')
      `,
        [
          debit_note_no,
          r.item_name || "Service",
          r.hsn || null,
          r.qty || 1,
          r.unit_id || null,
          r.price_per_unit || 0,
          r.tax_id || null,
          r.tax_percent || 0,
          taxAmount / 2,
          taxAmount / 2,
          0,
          taxAmount,
        ],
      );
    }

    // =========================
    // 7️⃣ FINAL CORRECT LEDGER ENTRY
    // =========================

    // PARTY DR

    await conn.execute(
      `
      INSERT INTO ledger_entries
      (
        company_id,
        entry_date,
        source_type,
        source_id,
        ledger_id,
        party_id,
        debit,
        credit,
        narration,
        status
      )
      VALUES(?,?,?,?,?,?,?,?,?,?)
    `,
      [
        company_id,
        voucher_date,
        "DEBIT_NOTE",
        debit_note_no,
        party_id,
        party_id,
        total,
        0,
        narration || "Purchase Return",
        "active",
      ],
    );

    // PURCHASE RETURN CR

    await conn.execute(
      `
      INSERT INTO ledger_entries
      (
        company_id,
        entry_date,
        source_type,
        source_id,
        ledger_id,
        debit,
        credit,
        narration,
        status
      )
      VALUES(?,?,?,?,?,?,?,?,?)
    `,
      [
        company_id,
        voucher_date,
        "DEBIT_NOTE",
        debit_note_no,
        PURCHASE_RETURN_LEDGER,
        0,
        total,
        narration || "Purchase Return",
        "active",
      ],
    );

    // 8️⃣ UPDATE PURCHASE DUE AGAIN

    await conn.execute(
      `
      UPDATE purchase_bill
      SET due_amount =
      GREATEST(due_amount - ?,0)
      WHERE supplier_invoice_no=?
      AND company_id=?
    `,
      [total, purchase_invoice_no, company_id],
    );

    await conn.commit();

    res.json({
      success: true,
      message: "Debit Note updated successfully",
      debit_note_no,
    });
  } catch (err) {
    await conn.rollback();

    console.error(err);

    res.status(500).json({
      success: false,
      error: err.message,
    });
  } finally {
    conn.release();
  }
};

exports.getNextDebitNoteNo = async (req, res) => {
  try {
    const { company_id } = req.params;

    if (!company_id) {
      return res.status(400).json({
        success: false,
        message: "company_id required",
      });
    }

    const [rows] = await db.execute(
      `SELECT * FROM prefix_master
       WHERE company_id=? 
       AND voucher_type='DN'
       AND is_active=1
       AND deleted_at IS NULL`,
      [company_id],
    );

    if (!rows.length) {
      return res.status(400).json({
        success: false,
        message: "DN prefix not configured",
      });
    }

    const config = rows[0];

    const nextNumber =
      config.current_number === 0
        ? config.start_number
        : config.current_number + 1;

    const padded = String(nextNumber).padStart(config.padding_length, "0");

    const preview = config.prefix_name + config.number_separator + padded;

    res.json({
      success: true,
      debit_note_no: preview,
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message,
    });
  }
};

exports.getDebitNoteReport = async (req, res, next) => {
  try {
    const company_id = req.company_id;

    const {
      fromDate,
      toDate,
      party_id,
      search,
      page = 1,
      limit = 20,
    } = req.query;

    if (!company_id) {
      return res.status(400).json({
        error: "company_id required",
      });
    }

    const pageNum = Number(page);
    const limitNum = Number(limit);
    const offset = (pageNum - 1) * limitNum;

    let where = `WHERE dn.company_id=? AND dn.status='active'`;
    const params = [company_id];

    if (party_id) {
      where += ` AND dn.party_id=?`;
      params.push(party_id);
    }

    if (fromDate && toDate) {
      where += ` AND dn.voucher_date BETWEEN ? AND ?`;
      params.push(fromDate, toDate);
    }

    if (search) {
      where += `
      AND (
        dn.debit_note_no LIKE ?
        OR dn.purchase_invoice_no LIKE ?
        OR p.company_name LIKE ?
      )
      `;

      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }

    /*
    MAIN DATA
    */

    const [rows] = await db.execute(
      `
SELECT

  dn.id,
  dn.debit_note_no,
  dn.purchase_invoice_no,
  dn.voucher_date,

  dn.party_id,
  p.company_name AS party_name,
  p.mobile_number,
  p.gst_number,

  dn.total_amount,
  dn.narration,
  dn.created_at

FROM debit_note dn

LEFT JOIN party p
ON p.id = dn.party_id

${where}

ORDER BY dn.voucher_date DESC

LIMIT ? OFFSET ?
`,
      [...params, limitNum, offset],
    );

    /*
    GET ITEMS
    */

    for (const r of rows) {
      const [items] = await db.execute(
        `
SELECT

  dni.item_name,
  dni.hsn,

  dni.qty,
  dni.price_per_unit,

  dni.tax_percent,

  dni.cgst_amount,
  dni.sgst_amount,
  dni.igst_amount,

  dni.tax_amount,

  (dni.price_per_unit * dni.qty) + dni.tax_amount
  AS total_amount

FROM debit_note_items dni

WHERE dni.debit_note_no=?
AND dni.status='active'
`,
        [r.debit_note_no],
      );

      r.items = items;
    }

    /*
    COUNT
    */

    const [countRows] = await db.execute(
      `
SELECT COUNT(*) AS total
FROM debit_note dn
LEFT JOIN party p ON p.id=dn.party_id
${where}
`,
      params,
    );

    /*
    SUMMARY
    */

    const [summary] = await db.execute(
      `
SELECT
SUM(dn.total_amount) AS total_debit_return
FROM debit_note dn
LEFT JOIN party p ON p.id=dn.party_id
${where}
`,
      params,
    );

    res.json({
      success: true,

      summary: summary[0],

      pagination: {
        page: pageNum,
        limit: limitNum,
        total: countRows[0].total,
        pages: Math.ceil(countRows[0].total / limitNum),
      },

      data: rows,
    });
  } catch (err) {
    next(err);
  }
};
