const db = require("../config/db");

const generateVoucherNumber = require("../utils/generateVoucherNumber");



exports.createJournal = async (req, res) => {
  const conn = await db.getConnection();

  try {
    const {
      company_id,
      voucher_no,
      voucher_date,
      narration,
      party_id,
      group_ledger_id,
      group_name,
      item_name,
      amount,
      paid,
      payment_type,
      payment_mode,
      bank_id,
      cheque_number,
      cheque_date,
      
    } = req.body;

    if (!company_id) throw new Error("company_id missing");

    if (!party_id || !group_ledger_id)
      throw new Error("Required fields missing");

    const finalAmount = Number(amount || 0);
    const finalPaid = Number(paid || 0);
    const finalDue = finalAmount - finalPaid;
    const payType = payment_type || "none";

    await conn.beginTransaction();

    // 🔥 VALIDATION BEFORE INSERT
    if (payment_mode === "CHEQUE") {
      if (!bank_id || !cheque_number || !cheque_date) {
        throw new Error("Cheque details required");
      }
    }

    if (
      payment_mode &&
      payment_mode !== "CASH" &&
      payment_mode !== "CHEQUE" &&
      !bank_id
    ) {
      throw new Error("Bank required for this payment mode");
    }

    // 🔥 AUTO GENERATE JOURNAL VOUCHER NUMBER
    const finalVoucherNo = await generateVoucherNumber(
      conn,
      company_id,
      "JOURNAL_VOUCHER",
    );

    // ✅ GET LEDGER ID & NUMBER (PARTY)
    const [[ledger]] = await conn.query(
      `
  SELECT id, ledger_number 
  FROM ledgers 
  WHERE party_id = ? 
  AND company_id = ?
  LIMIT 1
  `,
      [Number(party_id), Number(company_id)],
    );

    const ledger_id = ledger?.id || null;
    const ledger_number = ledger?.ledger_number || null;

    console.log("JOURNAL LEDGER:", ledger_id, ledger_number);

    /* ---- Journal Header ---- */

    const [jv] = await conn.query(
      `
      INSERT INTO jurnal_voucher
      (company_id, party_id,ledger_number, group_id, group_name,
       voucher_no, voucher_date, narration, item_name,
       amount, paid, due, payment_type, payment_mode, bank_id, cheque_number, cheque_date,status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?,'active')
      `,
      [
        company_id,
        party_id,
        ledger_number,
        group_ledger_id,
        group_name,
        finalVoucherNo,
        voucher_date,
        narration,
        item_name || null,
        finalAmount,
        finalPaid,
        finalDue,
        payType,
        // 🔥 NEW
        payment_mode || null,
        bank_id || null,
        cheque_number || null,
        cheque_date || null,
      ],
    );

    await conn.execute(
      `
  INSERT INTO ledger_entries
  (company_id, entry_date, source_type, source_id,
   ledger_id, party_id, debit, credit, narration)
  VALUES (?, ?, 'JOURNAL', ?, ?, ?, ?, 0, ?)
  `,
      [
        company_id,
        voucher_date,
        finalVoucherNo,
        ledger_id,
        party_id,
        finalAmount,
        narration || "Journal Entry",
      ],
    );

    /* ---- Group Ledger Cr ---- */
    await conn.execute(
      `
  INSERT INTO ledger_entries
  (company_id, entry_date, source_type, source_id,
   ledger_id, debit, credit, narration)
  VALUES (?, ?, 'JOURNAL', ?, ?, 0, ?, ?)
  `,
      [
        company_id,
        voucher_date,
        finalVoucherNo,
        group_ledger_id,
        finalAmount,
        narration || "Journal Entry",
      ],
    );

    /* ---- Receipt Entry (IF PAID) ---- */
    if (finalPaid > 0 && payType !== "none") {
      // Party CR (Payment received/made against party)
      await conn.execute(
        `
  INSERT INTO ledger_entries
  (company_id, entry_date, source_type, source_id,
   ledger_id, party_id, debit, credit, narration)
  VALUES (?, ?, 'RECEIPT', ?, ?, ?, 0, ?, ?)
  `,
        [
          company_id,
          voucher_date,
          finalVoucherNo,
          ledger_id,
          party_id,
          finalPaid,
          "Receipt against journal",
        ],
      );
    }

    await conn.commit();
    res.json({
      success: true,
      finalVoucherNo,
      message: "Journal created perfectly ✅",
    });
  } catch (err) {
    await conn.rollback();
    res.status(400).json({ error: err.message });
  } finally {
    conn.release();
  }
};

exports.updateJournal = async (req, res) => {
  const journalId = req.params.id;
  const conn = await db.getConnection();

  try {
    const {
      company_id,
      voucher_date,
      narration,
      party_id,
      group_id,
      group_name,
      item_name,
      amount = 0,
      paid = 0,
      payment_type = "none",
      payment_mode,
      bank_id,
      cheque_number,
      cheque_date,
    } = req.body;

    if (!company_id) throw new Error("company_id missing");

    const finalAmount = Number(amount);
    const finalPaid = Number(paid);
    const finalDue = finalAmount - finalPaid;

    await conn.beginTransaction();

    // 🔥 VALIDATION BEFORE INSERT
    if (payment_mode === "CHEQUE") {
      if (!bank_id || !cheque_number || !cheque_date) {
        throw new Error("Cheque details required");
      }
    }

    if (
      payment_mode &&
      payment_mode !== "CASH" &&
      payment_mode !== "CHEQUE" &&
      !bank_id
    ) {
      throw new Error("Bank required for this payment mode");
    }

    /* 1️⃣ Old journal */
    const [[old]] = await conn.query(
      `SELECT voucher_no, party_id, group_id, voucher_date
       FROM jurnal_voucher
      WHERE id=? AND company_id=? AND status='active'`,
      [journalId, company_id],
    );

    if (!old) throw new Error("Journal not found");

    const [[ledger]] = await conn.query(
      `SELECT id, ledger_number FROM ledgers WHERE party_id = ? AND company_id = ? LIMIT 1`,
      [Number(party_id || old.party_id), Number(company_id)],
    );
    const ledger_id = ledger?.id || null;

    const voucher_no = old.voucher_no;
    const finalPartyId = party_id ?? old.party_id;
    const finalGroupId = group_id ?? old.group_id;
    const finalDate = voucher_date ?? old.voucher_date;

    /* 2️⃣ Update journal header */
    await conn.query(
      `
      UPDATE jurnal_voucher
      SET voucher_date=?, narration=?, party_id=?, group_id=?,
          group_name=?, item_name=?, amount=?, paid=?, due=?, payment_type=?,  payment_mode=?,
    bank_id=?,
    cheque_number=?,
    cheque_date=?
      WHERE id=? AND company_id=?
      `,
      [
        finalDate,
        narration,
        finalPartyId,
        finalGroupId,
        group_name,
        item_name,
        finalAmount,
        finalPaid,
        finalDue,
        payment_type,
        payment_mode || null,
        bank_id || null,
        cheque_number || null,
        cheque_date || null,
        journalId,
        company_id,
      ],
    );

    /* 3️⃣ DELETE ALL OLD LEDGER (🔥 MAIN FIX) */
    await conn.query(
      `
      DELETE FROM ledger_entries
      WHERE source_id=? AND company_id=?
        AND source_type IN ('JOURNAL','RECEIPT')
      `,
      [voucher_no, company_id],
    );

    /* 4️⃣ JOURNAL ENTRIES */

    // Party DR
    await conn.execute(
      `
      INSERT INTO ledger_entries
      (company_id, entry_date, source_type, source_id,
       ledger_id, party_id, debit, credit, narration)
      VALUES (?, ?, 'JOURNAL', ?, ?, ?, ?, 0, ?)
      `,
      [
        company_id,
        finalDate,
        voucher_no,
        ledger_id,
        finalPartyId,
        finalAmount,
        narration,
      ],
    );

    // Group CR
    await conn.execute(
      `
      INSERT INTO ledger_entries
      (company_id, entry_date, source_type, source_id,
       ledger_id, debit, credit, narration)
      VALUES (?, ?, 'JOURNAL', ?, ?, 0, ?, ?)
      `,
      [company_id, finalDate, voucher_no, finalGroupId, finalAmount, narration],
    );

    /* 5️⃣ RECEIPT ENTRIES (ONLY IF PAID) */
    if (finalPaid > 0 && payment_type !== "none") {
      // Party CR
      await conn.execute(
        `
        INSERT INTO ledger_entries
        (company_id, entry_date, source_type, source_id,
         ledger_id, party_id, debit, credit, narration)
        VALUES (?, ?, 'RECEIPT', ?, ?, ?, 0, ?, ?)
        `,
        [
          company_id,
          finalDate,
          voucher_no,
          ledger_id,
          finalPartyId,
          finalPaid,
          "Receipt",
        ],
      );
    }

    await conn.commit();
    res.json({ success: true, message: "Journal updated perfectly ✅" });
  } catch (err) {
    await conn.rollback();
    res.status(400).json({ error: err.message });
  } finally {
    conn.release();
  }
};


exports.deleteJournal = async (req, res) => {
  const { id } = req.params;

  const [[voucher]] = await db.query(
    `SELECT voucher_no, company_id FROM jurnal_voucher WHERE id=?`,
    [id],
  );

  if (!voucher) {
    return res.status(404).json({ error: "Journal not found" });
  }

  await db.query(
    `UPDATE jurnal_voucher
     SET status='inactive', deleted_at=NOW()
     WHERE id=?`,
    [id],
  );

  await db.query(
    `DELETE FROM ledger_entries
     WHERE source_id=? AND company_id=?`,
    [voucher.voucher_no, voucher.company_id],
  );

  res.json({ success: true });
};

exports.getJournalById = async (req, res) => {
  const id = req.params.id;

  const [[header]] = await db.query(
    `SELECT 
        j.*,
        p.company_name AS party_name,
        p.gst_number   AS gst_no,
        p.address,
        p.city,
        p.state,
        p.pincode      AS pin,
        p.mobile_number AS mobile
     FROM jurnal_voucher j
     LEFT JOIN party p ON p.id = j.party_id
     WHERE j.id = ? AND j.status = 'active'`,
    [id],
  );

  if (!header) {
    return res.status(404).json({ error: "Journal not found" });
  }

  const [entries] = await db.query(
    `SELECT e.*, l.name AS ledger_name
     FROM jurnal_voucher_entries e
     JOIN ledgers l ON l.id = e.ledger_id
     WHERE e.jurnal_voucher_id = ?`,
    [id],
  );

  res.json({ header, entries });
};

exports.getJournalsByCompany = async (req, res) => {
  try {
    const company_id = req.params.company_id;

    const [rows] = await db.query(
      `SELECT 
          j.id,
          j.voucher_no,
          j.voucher_date,
          j.narration,

          j.amount,
          j.paid,
          j.due,
          j.payment_type,

          j.party_id,
          p.company_name AS party_name,

          j.group_id,
          j.group_name,
          j.item_name
       FROM jurnal_voucher j
       LEFT JOIN party p ON p.id = j.party_id
       WHERE j.company_id = ?
         AND j.status = 'active'
       ORDER BY j.id DESC`,
      [company_id],
    );

    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
